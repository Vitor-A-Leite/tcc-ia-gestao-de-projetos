TCC — Seção 2: Baseline com LLM

Conteúdo:
- Secao_2_Baseline_LLM.ipynb

Como usar:
1. Extraia este ZIP.
2. Abra o Google Colab.
3. Faça upload do arquivo Secao_2_Baseline_LLM.ipynb.
4. Execute a primeira célula para carregar o projeto do GitHub (sem Google Drive).
5. Configure OPENAI_API_KEY em Colab > Secrets.
6. Rode primeiro 1 cenário.
7. Depois rode os 6 novos casos piloto DEV001–DEV006.
8. Só após validar e congelar o prompt, altere RUN_FULL_EXPERIMENT para True.
9. Execute os 36 cenários e salve os resultados.

Observação:
O ground truth nunca deve ser enviado ao LLM durante a inferência.

Versão do prompt: BASELINE_V2.
Resultados: TCC_Codigos/outputs/baseline_v2 no checkout local.
Baixe ou preserve os resultados antes de encerrar uma sessão temporária do Colab.
