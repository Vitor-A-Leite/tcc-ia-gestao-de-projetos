TCC — Seção 2: Baseline com LLM

Conteúdo:
- Secao_2_Baseline_LLM.ipynb

Como usar:
1. Extraia este ZIP.
2. Abra o Google Colab.
3. Faça upload do arquivo Secao_2_Baseline_LLM.ipynb.
4. Ajuste PROJECT_DIR caso necessário.
5. Configure OPENAI_API_KEY em Colab > Secrets.
6. Rode primeiro 1 cenário.
7. Depois rode os 6 casos piloto.
8. Só após validar e congelar o prompt, altere RUN_FULL_EXPERIMENT para True.
9. Execute os 36 cenários e salve os resultados.

Observação:
O ground truth nunca deve ser enviado ao LLM durante a inferência.
